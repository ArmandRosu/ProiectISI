// export const environment = {
//   firebase: {
//     // add your Firebase config here 
//     apiKey: "AIzaSyDPFeqJuYwznOQcBtjts_KeQ3Jc8b8mxQs",
//     authDomain: "isi-lab5-761a5.firebaseapp.com",
//     databaseURL: "https://isi-lab5-761a5-default-rtdb.europe-west1.firebasedatabase.app",
//     projectId: "isi-lab5-761a5",
//     storageBucket: "isi-lab5-761a5.firebasestorage.app",
//     messagingSenderId: "433182853687",
//     appId: "1:433182853687:web:308f0147163fb79ffd8db2",
//     measurementId: "G-07YN04N5MM"  
//   },
//   production: true
// };
export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api', // URL-ul backend-ului
};

